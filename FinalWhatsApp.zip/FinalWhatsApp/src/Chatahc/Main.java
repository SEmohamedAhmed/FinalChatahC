package Chatahc;
import java.sql.*;
import java.time.LocalDate;


public class Main {
    public static void main(String[] args) throws SQLException {
        App app = new App();
        Date currentDate = Date.valueOf(LocalDate.now());
        LocalDate l = LocalDate.now();

    }
}
