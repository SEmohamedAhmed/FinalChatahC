package GUI;

import com.jfoenix.controls.JFXTextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.sql.SQLException;

import static GUI.Main.app;

public class AddStoryController {

    @FXML
    JFXTextArea storyJFXTextArea;
    private CustomAlert alert;
    //Verified
    public void addStory(ActionEvent actionEvent) throws SQLException, IOException {
        String newStoryText = storyJFXTextArea.getText();
        if(!newStoryText.equals(""))
        {
            app.addStory(HomeController.HomeUser.getId(),newStoryText);
            alert = new CustomAlert("Story Alert", "Story Was Added");
            alert.openAlert();
            storyJFXTextArea.clear();
        }
    }

    public void backToStoryPage(MouseEvent mouseEvent) throws IOException {
        Main.utilities.gotoHere("../UI/story_page.fxml",mouseEvent);
    }

}
