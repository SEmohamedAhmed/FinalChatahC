package GUI;

import cells.MessageCustomCell;
import cells.UserCustomCell;
import cells.UserListCell;
import Chatahc.ChatRoom;
import Chatahc.Message;
import Chatahc.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import static GUI.LoginController.uLogin;
import static GUI.Main.app;
import static GUI.Main.utilities;
import static GUI.SignUpController.uSignup;

public class HomeController implements Initializable {
    public static User HomeUser;
    public static int selectedMessage;
    public ObservableList<UserListCell> usersList = FXCollections.observableArrayList();
    public static UserListCell currentSelectedChatRoom=null;         //current opened chatroom
    @FXML private Label chatRoomName;
    @FXML private ListView<UserListCell> usersListView;
    @FXML private ListView<Message> messagesListView;
    @FXML private TextField messageTextField;
    @FXML private ImageView userHomeImage;
    private ProfileDescription profileDescription;
    public HomeController() {
       // System.out.println("initializedDoneeeeeee");
        if (uLogin != null)
            HomeUser = uLogin;
        else if (uSignup != null)
            HomeUser = uSignup;
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            prepareHomeScene();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void prepareHomeScene() throws SQLException {
        int userId = app.getUserIdFromUsername(HomeUser.getUsername());
        ArrayList<ChatRoom> chatRooms = app.expandConnectionChats(userId);
        ArrayList<UserListCell> allUserListCell = new ArrayList<>();
        for (int i = 0; i < chatRooms.size(); ++i) {
            ChatRoom tempChatRoom = chatRooms.get(i);
            // 0- handle empty chatroom
            UserListCell userListCell;
            if(tempChatRoom.getMessageList().isEmpty()) {
                userListCell = new UserListCell(tempChatRoom.getName(), tempChatRoom);
            }
            else {
                String cellName=tempChatRoom.getName();
                if(cellName==null)
                {
                    User y = getFriendUser(tempChatRoom);
                    cellName =y.getUsername();
                }
                userListCell = new UserListCell(cellName, tempChatRoom.getLastMessageSent().getMessageText(),
                        tempChatRoom.getLastMessageSent().getTime(), tempChatRoom);
            }
            ArrayList<Message> arrayList = tempChatRoom.getMessageList();
            ObservableList<Message> messageList = FXCollections.observableArrayList(arrayList);   //must be local not global
            userListCell.setMessagesList(messageList);
            allUserListCell.add(userListCell);
        }
        System.out.println("allUserListCell is done");
        usersList.addAll(allUserListCell);
        usersListView.setItems(usersList);
        userHomeImage.setImage(new Image(app.getUser(HomeUser.getId()).getUserImageLink()));
        System.out.println("Done showing lists");
        prepareHomeListsGui();
        System.out.println("Done showing lists graphically");

    }
    private void prepareHomeListsGui() {
        usersListView.setCellFactory(lv -> new UserCustomCell() {
            {

                //prefWidthProperty().bind(usersListView.widthProperty().subtract(0));
                lv.setOnMouseClicked(mouseEvent -> {
                    currentSelectedChatRoom = lv.getSelectionModel().getSelectedItem();
                });
            }
        });
        messagesListView.setCellFactory(lv -> new MessageCustomCell() {
            {
               // prefWidthProperty().bind(messagesListView.widthProperty().subtract(0));
                lv.setOnMouseClicked(mouseEvent -> {
                    if (mouseEvent.getClickCount() == 2) {
                        selectedMessage = lv.getSelectionModel().getSelectedIndex();
                        Message message = lv.getSelectionModel().getSelectedItem();
                        try {
                            utilities.doubleClickEvent(mouseEvent, message);     //message status
                        } catch (IOException ioException) {
                            System.out.println("messagesListView.setCellFactory problem");
                            ioException.printStackTrace();
                        }
                    }
                });
            }
        });
        usersListView.getSelectionModel().selectedItemProperty().addListener(l -> {
             UserListCell currentSelectedUserListCell = usersListView.getSelectionModel().getSelectedItem();
            messageTextField.setVisible(true);
            if(currentSelectedUserListCell!=null){
                chatRoomName.setText(currentSelectedUserListCell.userName);
                chatRoomName.setVisible(true);
                currentSelectedUserListCell.notificationsNumber = "0";        //erase notifs if u opened the chat
                messagesListView.setItems(currentSelectedUserListCell.getMessagesList());
                messagesListView.scrollTo(currentSelectedUserListCell.getMessagesList().size());
                chatRoomName.setText(currentSelectedUserListCell.userName);
            }
            if(currentSelectedChatRoom!=null)
            {
                try {
                    app.openChat(HomeUser,currentSelectedChatRoom.getChatRoom().getId());
                } catch (SQLException e) {
                    System.out.println("OpenChatFailed");
                    e.getMessage();
                }
                currentSelectedChatRoom = currentSelectedUserListCell;
            }
            else
            {
                currentSelectedChatRoom = currentSelectedUserListCell;
                try {
                    app.openChat(HomeUser,currentSelectedChatRoom.getChatRoom().getId());
                } catch (SQLException e) {
                    System.out.println("OverrideDateFailed");
                    e.printStackTrace();
                }
            }
        });
    }
    public void sendMessage(ActionEvent actionEvent) throws SQLException {
        // @FXML may solve bugs||errors
        String msgText = messageTextField.getText();
        if (!msgText.equals("")) {
            app.sendMessage(HomeUser.getId(), currentSelectedChatRoom.getChatRoom().getId(), msgText);
            updateAndClearList();
        }
    }
    public void updateAndClearList() throws SQLException {
        Message lastMessage = app.getLastMessage(currentSelectedChatRoom.getChatRoom().getId());
        messagesListView.getItems().add(lastMessage);
        messagesListView.scrollTo(messagesListView.getItems().size());

        currentSelectedChatRoom.lastMessage = lastMessage.getMessageText();
        currentSelectedChatRoom.time = lastMessage.getTime();

        usersListView.getItems().remove(currentSelectedChatRoom);
        usersListView.getItems().add(0, currentSelectedChatRoom);
        usersListView.refresh();
        usersListView.getSelectionModel().selectFirst();
        messageTextField.clear();
    }
    public static void deleteMessage() throws SQLException {
        Message deletedMessage = currentSelectedChatRoom.getMessagesList().remove(selectedMessage);
        app.deleteMessage(HomeUser.getId(), deletedMessage.getChatId(), deletedMessage.getId());
    }
    public void gotoStoryPage(MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/story_page.fxml", mouseEvent);
        //StoryController storyController=new StoryController();
    }
    public void gotoOptions(MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _change_Profile_Description_Scene.fxml", mouseEvent);
        //  OptionsController optionsController=new OptionsController();
    }
    public void gotoProfileDesc(MouseEvent mouseEvent) throws IOException, SQLException {
        // only 2 cases
        String node = mouseEvent.getSource().getClass().getName();
        UserListCell userListCell = usersListView.getSelectionModel().getSelectedItem();
        System.out.println(node);
        if (node.contains("Label"))                 //C1
        {
            boolean chatType = userListCell.isPrivate();    // -> chatType 0 : group , 1 : private
            //  System.out.println("LabelClicked");
            if(!chatType) {
                profileDescription = new ProfileDescription(userListCell.getChatRoom().getChatroomImageLink(), userListCell.userName,"");
            }
            else
            {
               User curFriend =getFriendUser(userListCell.getChatRoom());
               if(curFriend.isProfileVisibility())
               {
                   profileDescription = new ProfileDescription(curFriend.getUserImageLink(),
                           curFriend.getUsername(),curFriend.getProfileDesc());
               }
               else
               {
                   String testIsFriend = app.getFriendName(HomeUser.getId(), curFriend.getId());
                  // System.out.println("Error");
                   if(testIsFriend != null)
                   {
                       profileDescription = new ProfileDescription(curFriend.getUserImageLink(),
                               curFriend.getUsername(),curFriend.getProfileDesc());
                   }
                   else
                   {
                       profileDescription = new ProfileDescription("C:\\Users\\future\\IdeaProjects\\FinalWhatsApp\\src\\resources\\img\\userDefaultImage.png",
                               "","");
                   }
               }
            }
        }
        /*if (node.contains("ImageView"))  */
        else {
            profileDescription = new ProfileDescription(app.getUser(HomeUser.getId()).getUserImageLink(), HomeUser.getUsername(), app.getUser(HomeUser.getId()).getProfileDesc());
            System.out.println("userImageClicked");
        }
        profileDescription.openProfile();
    }
    public User getFriendUser(ChatRoom chatRoom) throws SQLException {
        ArrayList<User> arrayList = chatRoom.getUserList();
        for (User u:arrayList)
        {
            if (u.getId()!=HomeUser.getId())
                return app.getUser(u.getId());
        }
        return null;
    }
}