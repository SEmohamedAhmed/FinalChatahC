package GUI;

import cells.StoryCustomCell;
import cells.StoryListCell;
import Chatahc.Story;
import Chatahc.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import static GUI.HomeController.HomeUser;
import static GUI.Main.app;
import static GUI.Main.utilities;

//
public class StoryController implements Initializable{

    @FXML private Label storyRoomName;
    @FXML private Label storyTime;
    @FXML private ImageView userImage;
    @FXML private Label currentStoryText;
    @FXML private HBox storyButtonsBar;
    @FXML private ListView<StoryListCell>userListView;
    private static ArrayList<Story>currentStoryList;
    private static int currentStoryIndex;
    private ObservableList<StoryListCell> usersList;
    public StoryController(){}       //def constructor

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            prepareStories();
        } catch (Exception e) {
            System.out.println("StoryInitialization failed");
            e.getMessage();
        }
    }
    private void prepareStories() throws SQLException {
        ArrayList<User> friendsList = app.getFriendList(HomeUser.getId()); //to be moved
        ArrayList<StoryListCell>allListCells= new ArrayList<>();
        // add current user stories first
        ArrayList<Story>homeStories=app.getStoryList(HomeUser.getId());
        if(!homeStories.isEmpty())
        {
            StoryListCell curUser=new StoryListCell(HomeUser);
            curUser.setStoriesUserList(homeStories);
            curUser.userName="My Stories";
            allListCells.add(curUser);
        }
        for(User user:friendsList)
        {
            if(user!=null)
            {
                System.out.println("friend");
                ArrayList<Story>userStories = app.getStoryList(user.getId());
                if(!userStories.isEmpty())        //this friend has stories
                {
                    System.out.println(userStories.get(0).getStoryText());
                    System.out.println("userStories is not empty");
                    StoryListCell storyListCell = new StoryListCell(user);
                    storyListCell.setStoriesUserList(app.getStoryList(user.getId()));
                    allListCells.add(storyListCell);
                    System.out.println("1 storyAdded");
                }
            }
        }

        System.out.println("loop ened successfully");
        usersList = FXCollections.observableArrayList(allListCells);
        System.out.println(usersList.size());
        if(usersList!=null) {
            userListView.setItems(usersList);
            prepareStoriesGUI();
        }
    }
    private void prepareStoriesGUI(){
        userImage.setImage(new Image(HomeUser.getUserImageLink()));
        userListView.setCellFactory(lv -> new StoryCustomCell() {
            {
               // prefWidthProperty().bind(userListView.widthProperty().subtract(0));
            }
        });
        userListView.getSelectionModel().selectedItemProperty().addListener(s -> {
            prepareStoriesFirstView();
        });
    }
    private void prepareStoriesFirstView() {
        StoryListCell storyListCell = userListView.getSelectionModel().getSelectedItem();
        currentStoryList = storyListCell.getStoriesUserList();
        currentStoryIndex = 0;
        currentStoryText.setText(currentStoryList.get(0).getStoryText());
        storyRoomName.setText(storyListCell.userName);
        currentStoryText.setVisible(true);
        storyRoomName.setVisible(true);
        storyTime.setVisible(true);
        storyButtonsBar.setVisible(true);
        storyTime.setText(utilities.getTimeHHMM(String.valueOf(currentStoryList.get(0).getStoryUploadedTime())));
    }
    public void prevStory(ActionEvent actionEvent) {
        if(currentStoryIndex-1 > -1)
        {
            currentStoryIndex--;
            Story currentStory=currentStoryList.get(currentStoryIndex);
            setStory(currentStory);
        }
    }
    public void nextStory(ActionEvent actionEvent) {
        if(currentStoryIndex+1 < currentStoryList.size())
        {
            currentStoryIndex++;
            Story currentStory=currentStoryList.get(currentStoryIndex);
            setStory(currentStory);
        }
    }
    private void setStory(Story currentStory) {
        currentStoryText.setText(currentStory.getStoryText());
        storyTime.setText(utilities.getTimeHHMM(String.valueOf(currentStory.getStoryUploadedTime())));
    }
    public void gotoHome(MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/home_view.fxml",mouseEvent);
    }
    public void gotoTypeStory(ActionEvent actionEvent) throws IOException {
        utilities.gotoHere("../UI/type_story.fxml",actionEvent);
    }
}
