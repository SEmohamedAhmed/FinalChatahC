package GUI;

import Chatahc.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.sql.SQLException;

import static GUI.Main.app;

public class SignUpController
{
    // make Your app scene resizable property false.
    @FXML
    private TextField phoneID;
    @FXML
    private TextField userName;
    @FXML
    private PasswordField password;

    public Scene scene;
    public Parent root;
    public static User uSignup = null;
    private CustomAlert alert;
    public void switchToLogin(ActionEvent actionEvent) throws IOException {
        Main.utilities.gotoHere("../UI/Login.fxml",actionEvent);
    }
    public void SetProfile(ActionEvent actionEvent) throws IOException, SQLException {
        if(dataValidation(actionEvent))
        {
            Main.utilities.gotoHere("../UI/SetProfilePhoto.fxml",actionEvent);
        }
    }
    public boolean dataValidation(ActionEvent actionEvent) throws SQLException, IOException {
        uSignup = new User(-1, userName.getText(), password.getText(), phoneID.getText());
       int choice= app.userDataValidation(uSignup);
       if(choice == 0)
       {
            return true;
       }
       else if(choice == 1)
       {
           alert = new CustomAlert("Signup Failed","Username exists");
       }
       else if(choice == 2)
       {
           alert = new CustomAlert("Signup Failed","Phone number exists");
       }
       else if(choice == 3)
       {
           alert = new CustomAlert("Signup Failed","Phone number can contains numbers only");
       }
       else if(choice == -1)
       {
           alert = new CustomAlert("Signup Failed","Empty field(s)");
       }
        alert.openAlert();
        return false;
    }

}
