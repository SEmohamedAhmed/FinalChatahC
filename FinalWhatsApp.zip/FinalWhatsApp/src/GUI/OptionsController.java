package GUI;

import Chatahc.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static GUI.HomeController.HomeUser;
import static GUI.Main.app;
import static GUI.Main.utilities;

// implements Initializable
public class OptionsController implements Initializable{
    @FXML private ImageView userImage;
    @FXML private TextField bioTextField;
    @FXML private PasswordField passwordField;
    @FXML private  TextField contactName;
    @FXML private TextField contactNumber;
    private File uploadedImage;
    protected CustomAlert alert;
    private User u = null;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            u = app.getUser(HomeUser.getId());
            userImage.setImage(new Image(app.getUser(HomeUser.getId()).getUserImageLink()));
            bioTextField.setText(u.getProfileDesc());
            System.out.println("optionOpened");
        } catch (Exception e) {
            System.out.println("Options Initialization failed");
            e.getMessage();
        }
        }
    public void goto1 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _change_Profile_Description_Scene.fxml", mouseEvent);
    }
    public void goto2 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _Password_Scene.fxml", mouseEvent);
    }
    public void goto3 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _Profile_Privacy_Scene.fxml", mouseEvent);

    }
    public void goto4 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _ContactsList_Scene_HandeledbylistView.fxml", mouseEvent);
    }
    public void goto5 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _AddNewContact.fxml", mouseEvent);
    }
    public void goto6 (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/Options _AddNewGroup_handeledbylistView.fxml", mouseEvent);
    }
    public void gotoHome (MouseEvent mouseEvent) throws IOException {
        utilities.gotoHere("../UI/home_view.fxml", mouseEvent);
    }
    public void uploadPhoto(ActionEvent actionEvent) {
        Stage currentSatge = utilities.getCurrentStage(actionEvent);
        uploadedImage = utilities.uploadImage(currentSatge);
        if(uploadedImage!=null)
        {
            Image userNewImage = new Image(uploadedImage.getAbsolutePath());
            userImage.setImage(userNewImage);
        }
    }
    public void saveProfileDescChanges(ActionEvent actionEvent) throws SQLException, IOException {
        if (uploadedImage != null) {
            System.out.println(uploadedImage.getAbsolutePath());
            app.resetUserImage(HomeUser.getId(),uploadedImage.getAbsolutePath());
            System.out.println("Image was reset");
        }
        String profileDesc = bioTextField.getText();
        if(!HomeUser.getProfileDesc().equals(profileDesc)&&!profileDesc.equals("")) {
            app.resetUserDesc(HomeUser.getId(),profileDesc);
            System.out.println("profile Desc was reset");
        }
        alert = new CustomAlert("Changes saved", "All is done");
        alert.openAlert();
    }
    public void resetPassword(ActionEvent actionEvent) throws SQLException, IOException {
        String newPassword = passwordField.getText();
        if(!newPassword.equals(""))
        {
            app.resetPassword(HomeUser.getId(), newPassword);
            passwordField.clear();
            alert = new CustomAlert("Password change", "Password was reset successfully");
            alert.openAlert();
        }
    }
    public void addNewContact(ActionEvent actionEvent) throws SQLException, IOException {
        User newContact = isValidContact(contactName.getText(),contactNumber.getText());
        if(newContact != null) {
            if(newContact.getPhoneNumber().equals(HomeUser.getPhoneNumber())) {
                alert = new CustomAlert("Contact was not added", "You cant add yourself");
            }
            else {
                app.addConnection(HomeUser.getId(),newContact.getId(),contactName.getText());
                alert = new CustomAlert("Contact was added", "Contact was added successfully");
            }
        }
        else {
            alert =new CustomAlert("Contact was not added", "Enter the data correctly");
        }
        alert.openAlert();
    }
    private User isValidContact(String contName,String phoneNum) throws SQLException {
        if(contName.equals("") || phoneNum.equals("")||!utilities.checkPhoneNum(phoneNum))
            return null;
        return app.getUserByPhoneNumber(phoneNum);
    }
    public void logout(MouseEvent mouseEvent) throws IOException {
        HomeUser = LoginController.uLogin = SignUpController.uSignup=null;
        System.out.println("You have logged out and cur user is "+ HomeUser);
        utilities.gotoHere("../UI/Login.fxml", mouseEvent);
    }
}
