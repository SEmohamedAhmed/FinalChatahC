package GUI;

import Chatahc.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import static GUI.Main.app;
import static GUI.Main.utilities;
import static GUI.SignUpController.uSignup;

public class SetProfile
{
    @FXML
    public GridPane pane;
    @FXML
    private TextField userDesc;
    @FXML
    private ImageView userImage;
    @FXML
    public User currentUser = uSignup;
    private String imageLink = "resources/img/userDefaultImage.png";    //default image

   public void chooseImage(ActionEvent actionEvent) throws SQLException, FileNotFoundException {
       currentUser.setUserImageLink(imageLink);     //initial photo
       Stage stage = utilities.getCurrentStage(actionEvent);
       File selectedFile = utilities.uploadImage(stage);
       if (selectedFile != null)
           imageLink = selectedFile.getAbsolutePath();
       currentUser.setUserImageLink(imageLink);         //save in db ?
       userImage.setImage(new Image(imageLink));
   }

    public void switchToHome(ActionEvent actionEvent) throws SQLException, IOException {
        String userDes = userDesc.getText();
        if(!userDes.equals(""))
        {
            currentUser.setProfileDesc(userDes);
        }
        app.registerForUser(currentUser);
        uSignup.setId(app.getLastUserId());
        app.resetUserImage(uSignup.getId(),imageLink);
        utilities.gotoHere("../UI/home_view.fxml",actionEvent);
    }
}

