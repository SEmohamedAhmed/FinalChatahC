package cells;

import Chatahc.ChatRoom;
import Chatahc.Message;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.image.Image;
import java.sql.SQLException;

import static GUI.Main.app;

public class UserListCell {
    public String userName;
    public String lastMessage;
    public String time;
    public String notificationsNumber;
    public Image userImage;
    public ObservableList<Message> messagesList;
    private ChatRoom chatRoom;
    public UserListCell(String userName, String lastMessage, String time,ChatRoom chatRoom) throws SQLException {
        this.userName = userName;
        this.lastMessage = lastMessage;
        this.time = time;
        this.notificationsNumber = Integer.toString(chatRoom.getNumberOfUnreadMessagesForCurrentUser());
        //
        //chatRoom.getChatroomImageLink()
        this.userImage = new Image("/resources/img/userDefaultImage.png");   //Default Image For Any User
        messagesList = FXCollections.observableArrayList();
        this.chatRoom=chatRoom;
    }
    public UserListCell(String userName,ChatRoom chatRoom){
        this.userName = userName;
        this.lastMessage = "";
        this.time = "";
        this.notificationsNumber = Integer.toString(chatRoom.getNumberOfUnreadMessagesForCurrentUser());
        this.userImage = new Image(chatRoom.getChatroomImageLink());   //Default Image For Any User
        messagesList = FXCollections.observableArrayList();
        this.chatRoom=chatRoom;
    }
    public ChatRoom getChatRoom() {
        return chatRoom;
    }
    public void setChatRoom(ChatRoom chatRoom) {
        this.chatRoom = chatRoom;
    }
    public ObservableList<Message> getMessagesList() {
        return messagesList;
    }
    public void setMessagesList(ObservableList<Message> messagesList) {
        this.messagesList = messagesList;
    }
    public String getNotificationsNumber() {
        return notificationsNumber;
    }
    public void setNotificationsNumber(String notificationsNumber) {
        this.notificationsNumber=notificationsNumber;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getLastMessage() {
        return lastMessage;
    }
    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public Image getAvatarImage() {
        return userImage;
    }
    public void setAvatarImage(Image avatarImage) {
        this.userImage = avatarImage;
    }
    public boolean isPrivate() throws SQLException {
       return app.isPrivate(chatRoom.getId());
    }
}