package cells;
import Chatahc.Story;
import Chatahc.User;

import java.util.ArrayList;

public class StoryListCell {
    public User user;
    public String userName;
    public String userImage;
    public ArrayList<Story> storiesUserList;
    public StoryListCell(User user) {
        userName = user.getUsername();
        this.user=user;
        this.userImage = user.getUserImageLink();
       // System.out.println(user.getUserImageLink());
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserImage() {
        return userImage;
    }
    public void setUserImage(String userImage) {
        this.userImage = userImage;
    }
    public ArrayList<Story> getStoriesUserList() {
        return storiesUserList;
    }
    public void setStoriesUserList(ArrayList<Story> storiesUserList) {
        this.storiesUserList = storiesUserList;
    }
}
